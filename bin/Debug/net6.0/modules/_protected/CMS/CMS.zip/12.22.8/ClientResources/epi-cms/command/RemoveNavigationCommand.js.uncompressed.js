define("epi-cms/command/RemoveNavigationCommand", [
    "dojo/_base/declare",
    "dojo/topic",
    "epi/dependency",
    "epi/i18n!epi/shell/ui/nls/episerver.shell.ui.resources.gadgetchrome",
    "epi/shell/command/_Command",
    "epi/shell/ViewSettings",
    "epi/shell/DialogService",
    "epi-cms/ApplicationSettings",
    "epi/i18n!epi/shell/ui/nls/episerver.shell.ui.resources.gadgetchrome"
], function (declare, topic, dependency, resources, _Command, viewSettings, dialogService, ApplicationSettings, res) {
    return declare([_Command], {
        // summary:
        //      A command that removes either Main Navigation or Assets components
        //
        // tags:
        //      internal

        constructor: function (params) {
            this.navigation = params ? params.navigation : false;
            var registry = dependency.resolve("epi.storeregistry");
            this._componentsStore = this._componentsStore || registry.get("epi.shell.component");
        },

        label: resources.deletemenuitemlabel,

        category: "setting",

        order: 1000,

        canExecute: true,

        _showRemovalConfirmationDialog: function () {
            return dialogService.confirmation({
                description: res.removecomponentquestionwithoutname,
                title: res.deletemenuitemlabel
            });
        },

        _execute: function () {
            this._showRemovalConfirmationDialog().then(
                function () {
                    this._componentsStore.query({ viewName: viewSettings.viewName }).then(
                        function (components) {
                            var componentKey = this.navigation ? ApplicationSettings.mainNavigationComponentKey : ApplicationSettings.assetsComponentKey;

                            var component = components.find(function (x) {
                                return x.settings.headingLocalizationKey === componentKey;
                            });

                            if (!component) {
                                return;
                            }

                            component.settings.isHidden = true;

                            this._componentsStore.executeMethod("save", "", [component]).then(function () {
                                topic.publish("/epi/cms/action/togglecomponent", {
                                    key: componentKey,
                                    isHidden: true
                                });
                            });
                        }.bind(this)
                    );
                }.bind(this)
            );
        }
    });
});
