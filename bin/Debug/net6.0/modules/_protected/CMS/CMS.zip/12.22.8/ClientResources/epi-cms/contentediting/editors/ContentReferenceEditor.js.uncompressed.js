require({cache:{
'url:epi-cms/contentediting/editors/templates/ContentReferenceEditor.html':"<div class=\"dijitInline\" tabindex=\"-1\" role=\"presentation\">\r\n    <div class=\"epi-content-reference-header-block\" data-dojo-attach-point=\"allowedTypesHeaderContainer\">\r\n        <div data-dojo-attach-point=\"allowedTypesHeader\"></div>\r\n    </div>\r\n    <div data-dojo-attach-point=\"container,dropAreaNode\" />\r\n</div>\r\n"}});
define("epi-cms/contentediting/editors/ContentReferenceEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/on",
    "dojo/when",

    // epi.cms
    "epi-cms/widget/SelectorWrapperBase",
    "epi-cms/core/ContentReference",
    "epi-cms/widget/_ContentSelectorActionsMixin",
    "epi-cms/widget/ContentSelector",
    "epi-cms/widget/MediaSelector",
    "epi-cms/widget/ThumbnailSelector",
    "epi-cms/contentediting/AllowedTypesList",
    "epi-cms/contentediting/command/BlockInlineEdit",

    // resources
    "dojo/text!./templates/ContentReferenceEditor.html"
], function (
    // dojo
    declare,
    on,
    when,

    // epi.cms
    SelectorWrapperBase,
    ContentReference,
    _ContentSelectorActionsMixin,
    ContentSelector,
    MediaSelector,
    ThumbnailSelector,
    AllowedTypesList,
    BlockInlineEdit,

    // resources
    template
) {

    return declare([SelectorWrapperBase], {
        // summary:
        //    Represents the widget to select ContentReference.
        // tags:
        //      internal xproduct

        templateString: template,

        baseClass: "epi-content-reference-wrapper",

        hideAllowedTypesList: false,

        postMixInProperties: function () {
            // summary:
            //    Initialize properties
            // tags:
            //    protected

            this.selectorClass = this._getContentSelectorType();
            this.inherited(arguments);
        },

        buildRendering: function () {
            // summary:
            //    Creates and append the input hidden field to the dom to preserve the contentLink id
            // tags:
            //    protected

            this.inherited(arguments);

            this.allowedTypesList = new AllowedTypesList({
                defaultAllowedTypes: this.defaultAllowedTypes,
                allowedTypes: this.allowedTypes,
                restrictedTypes: this.restrictedTypes
            });

            this.allowedTypesList.placeAt(this.allowedTypesHeader);

            this.own(
                on(this.domNode, "dblclick", function () {
                    if (this.contentSelector.model && this.contentSelector.model.capabilities && this.contentSelector.model.capabilities.isBlock) {
                        var inlineEditCommand = new BlockInlineEdit();
                        when(inlineEditCommand.updateModel(this.contentSelector.model)).then(function () {
                            inlineEditCommand.execute();
                        });
                    }
                }.bind(this))
            );

            this.allowedTypesList.startup();
            this.own(this.allowedTypesList);
        },

        postCreate: function () {
            this.inherited(arguments);

            this._updateStyle();
            this.own(this.allowedTypesList.watch("hasRestriction", this._updateStyle.bind(this)));
        },

        _onSelectorValueChange: function (contentLink) {
            if (!ContentReference.compareIgnoreVersion(this.value, contentLink)) {
                this.onFocus();
                this.value = contentLink;
                this._triggerSave();
            }
        },

        _getContentSelectorType: function () {
            if (this._isSelectorFor("episerver.core.icontentimage")) {
                return ThumbnailSelector;
            }

            if (this._isSelectorFor("episerver.core.icontentmedia")
                || this._isSelectorFor("episerver.core.icontentvideo")) {
                return declare([MediaSelector, _ContentSelectorActionsMixin], {});
            }

            return declare([ContentSelector, _ContentSelectorActionsMixin], {});
        },

        _isSelectorFor: function (typeIdentifier) {
            // summary:
            //      Determine which editor descriptor is used
            return this.defaultAllowedTypes && this.defaultAllowedTypes.indexOf(typeIdentifier) > -1;
        },

        _updateStyle: function () {
            // summary:
            //      Handle the widget style depending on the allowedTypesList visibility

            if (!this.domNode) {
                return;
            }

            this.domNode.classList.remove("allowed-types-list-hidden");
            this.allowedTypesHeader.classList.remove("dijitHidden");

            if (this.allowedTypesList.get("hasRestriction") === false) {
                this.domNode.classList.add("allowed-types-list-hidden");
            }

            if (this.hideAllowedTypesList) {
                this.allowedTypesHeaderContainer.classList.add("dijitHidden");
            }
        }
    });
});
